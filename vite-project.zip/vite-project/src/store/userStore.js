import { defineStore } from "pinia";
export default defineStore('user',{
    state(){
        return{
            username:'',
            password:'',
        }
    },
    actions:{
        setData(){
            localStorage.setItem('username',this.username)
            localStorage.setItem('password',this.password)
        }
    }
})