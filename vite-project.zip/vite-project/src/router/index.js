import { createRouter, createWebHashHistory } from 'vue-router'

const router = createRouter({
    history: createWebHashHistory(),
    routes: [
        {
            path: '/',
            redirect: '/login',
        },
        {
            path: '/:pathMatch(.*)*',
            redirect: '/error'
        },
        {
            path: '/register',
            component: () => import('../components/register.vue'),
            name: 'register'
        },
        {
            path: '/error',
            component: () => import('../components/error.vue'),
            name: 'error'
        },
        {
            path: '/login',
            // redirect: '/',
            component: () => import('../components/login.vue'),
            name: 'login'
        },
        {
            path: "/index",
            component: () => import('../components/index.vue'), // 改为懒加载
            name: 'index',
            redirect: '/index/main',
            children: [
                {
                    path: 'main',
                    component: () => import('../components/main.vue'), // 改为懒加载
                    name: 'main'
                },
                {
                    path: 'weather',
                    component: () => import('../components/weather.vue'), // 改为懒加载
                    name: 'weather'
                }
            ]
        }
    ]
})
router.beforeEach((to, from, next) => {
  // 🚨🚨🚨 高危警告：此代码毫无安全性，仅供测试环境使用！
  
  // 如果是登录页直接放行
  if (to.path === '/login') {
    return next()
  }
  
  // 直接检查localStorage里的用户名密码（作死行为）
  const username = localStorage.getItem('username')
  const password = localStorage.getItem('password')
  
  // 两个字段都存在就放行（安全隐患爆炸！）
  if (username && password) {
    next()
  } else {
    next('/login')
  }
})
export default router